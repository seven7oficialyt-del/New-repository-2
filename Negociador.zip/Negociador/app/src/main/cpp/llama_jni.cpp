// Puente JNI mínimo hacia llama.cpp. API de llama.cpp reciente (llama_model_load_from_file, llama_memory_clear).
// Si tu versión de llama.cpp difiere, ajusta nombres aquí.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include "llama.h"

#define TAG "llamajni"
struct Handle { llama_model* model; llama_context* ctx; };

// Mueve a `out` solo secuencias UTF-8 completas; deja la cola incompleta en `pending`.
static void take_valid(std::string& pending, std::string& out) {
    size_t i = 0, n = pending.size();
    while (i < n) {
        unsigned char c = pending[i];
        size_t len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
        if (len == 0) { i++; continue; }          // byte inválido: se descarta
        if (i + len > n) break;                    // secuencia incompleta: esperar
        out.append(pending, i, len); i += len;
    }
    pending.erase(0, i);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_negociador_LlamaBridge_load(JNIEnv* env, jobject, jstring jpath, jint nCtx, jint threads) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    llama_model* model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!model) return 0;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx; cp.n_batch = 512; cp.n_ubatch = 512;
    cp.n_threads = threads; cp.n_threads_batch = threads;
    llama_context* ctx = llama_init_from_model(model, cp);
    if (!ctx) { llama_model_free(model); return 0; }
    return (jlong) new Handle{model, ctx};
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_negociador_LlamaBridge_free(JNIEnv*, jobject, jlong h) {
    auto* H = (Handle*) h; if (!H) return;
    llama_free(H->ctx); llama_model_free(H->model); delete H;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_negociador_LlamaBridge_generate(JNIEnv* env, jobject, jlong h, jstring jprompt,
                                                  jint maxTokens, jfloat temp, jobject cb) {
    auto* H = (Handle*) h; if (!H) return JNI_FALSE;
    const llama_vocab* vocab = llama_model_get_vocab(H->model);
    const char* p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p); env->ReleaseStringUTFChars(jprompt, p);

    int n = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, false, true);
    if (n <= 0) return JNI_FALSE;
    std::vector<llama_token> toks(n);
    if (llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), n, false, true) < 0) return JNI_FALSE;
    if (n + maxTokens > (int) llama_n_ctx(H->ctx)) { __android_log_print(ANDROID_LOG_ERROR, TAG, "contexto excedido"); return JNI_FALSE; }

    llama_memory_clear(llama_get_memory(H->ctx), true);
    for (int i = 0; i < n; i += 512) {
        int cnt = std::min(512, n - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(H->ctx, b) != 0) return JNI_FALSE;
    }

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temp <= 0.01f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(20));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.8f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)Z");
    std::string pending, out;
    bool ok = true;
    for (int i = 0; i < maxTokens; i++) {
        llama_token t = llama_sampler_sample(smpl, H->ctx, -1);
        if (llama_vocab_is_eog(vocab, t)) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, t, buf, sizeof(buf), 0, true);
        if (len > 0) pending.append(buf, len);
        out.clear(); take_valid(pending, out);
        if (!out.empty()) {
            jstring js = env->NewStringUTF(out.c_str());
            jboolean cont = env->CallBooleanMethod(cb, mid, js);
            env->DeleteLocalRef(js);
            if (!cont) break;
        }
        llama_batch b = llama_batch_get_one(&t, 1);
        if (llama_decode(H->ctx, b) != 0) { ok = false; break; }
    }
    llama_sampler_free(smpl);
    return ok ? JNI_TRUE : JNI_FALSE;
}
