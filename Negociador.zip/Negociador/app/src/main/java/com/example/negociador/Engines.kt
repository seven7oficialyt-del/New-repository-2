package com.example.negociador

import android.media.*
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.isActive
import java.io.File
import kotlin.coroutines.coroutineContext

fun interface TokenCallback { fun onToken(piece: String): Boolean }

object LlamaBridge {
    init { System.loadLibrary("llamajni") }
    external fun load(path: String, nCtx: Int, threads: Int): Long
    external fun generate(h: Long, prompt: String, maxTokens: Int, temp: Float, cb: TokenCallback): Boolean
    external fun free(h: Long)
}

/** Qwen3-0.6B vía llama.cpp. */
class Llm(path: String) {
    private var h: Long = LlamaBridge.load(path, 2048, Runtime.getRuntime().availableProcessors().div(2).coerceIn(2, 4))
    val ok get() = h != 0L
    @Synchronized fun gen(prompt: String, max: Int, temp: Float, onTok: (String) -> Boolean): Boolean =
        h != 0L && LlamaBridge.generate(h, prompt, max, temp, TokenCallback { onTok(it) })
    @Synchronized fun close() { if (h != 0L) { LlamaBridge.free(h); h = 0 } }
}

/** Whisper (sherpa-onnx), offline, español. */
class Asr(dir: File) {
    private val rec = OfflineRecognizer(
        config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = File(dir, "base-encoder.int8.onnx").path,
                    decoder = File(dir, "base-decoder.int8.onnx").path,
                    language = "es", task = "transcribe"),
                tokens = File(dir, "base-tokens.txt").path,
                numThreads = 2, provider = "cpu", modelType = "whisper")))
    fun transcribe(samples: FloatArray): String {
        val s = rec.createStream()
        s.acceptWaveform(samples, 16000)
        rec.decode(s)
        val t = rec.getResult(s).text.trim()
        s.release()
        return t
    }
    fun close() = rec.release()
}

/** Piper es_ES (sherpa-onnx TTS) + reproducción por AudioTrack. */
class Tts(dir: File) {
    private val tts = OfflineTts(
        config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(
                    model = File(dir, "es_ES-davefx-medium.onnx").path,
                    tokens = File(dir, "tokens.txt").path,
                    dataDir = File(dir, "espeak-ng-data").path),
                numThreads = 2, provider = "cpu")))
    val voices get() = tts.numSpeakers()

    /** Genera y reproduce; se detiene si la corrutina se cancela. */
    suspend fun speak(text: String, speed: Float, volume: Float, voice: Int = 0) {
        val audio = tts.generate(text = text, sid = voice, speed = speed)
        val sr = audio.sampleRate
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(minBuf * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
        try {
            track.setVolume(volume); track.play()
            var i = 0; val x = audio.samples
            while (i < x.size && coroutineContext.isActive) {
                val n = minOf(4096, x.size - i)
                track.write(x, i, n, AudioTrack.WRITE_BLOCKING); i += n
            }
        } finally { track.pause(); track.flush(); track.release() }
    }
    fun close() = tts.release()
}
