package com.example.negociador

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: GameVM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) {
            Column(Modifier.systemBarsPadding().padding(12.dp)) {
                when (vm.screen) { Screen.SETUP -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { Setup(vm) }; Screen.CALL -> Call(vm); Screen.RESULT -> Result(vm) }
            } } } }
    }
}

@Composable fun ColumnScope.Setup(vm: GameVM) {
    Text("Negociador — prototipo", style = MaterialTheme.typography.headlineSmall)
    Text("Descarga los 3 modelos (una vez). Después todo funciona sin conexión.", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(vm.useCloud, { vm.useCloud = it; vm.saveCfg() }); Text("  Usar IA en la nube (OpenRouter)")
        }
        if (vm.useCloud) {
            Text("Necesita internet; lo que dices se envía a OpenRouter. Crea tu clave en openrouter.ai (menú Keys). Los modelos gratis tienen límite diario.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(vm.cloudKey, { vm.cloudKey = it; vm.saveCfg() }, Modifier.fillMaxWidth(), label = { Text("Clave (sk-or-v1-…)") },
                singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(vm.cloudModel, { vm.cloudModel = it; vm.saveCfg() }, Modifier.fillMaxWidth(), label = { Text("Modelo") }, singleLine = true)
        }
    } }
    vm.specs.forEach { s ->
        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(12.dp)) {
            Text(s.label, style = MaterialTheme.typography.titleSmall)
            Text(vm.sizeText(s.id), style = MaterialTheme.typography.bodySmall)
            val p = vm.progress[s.id]
            if (p != null) { LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
                TextButton(onClick = { vm.cancelDownload(s.id) }) { Text("Cancelar") } }
            else if (vm.ready[s.id] == true) Text("✔ Descargado")
            else Button(onClick = { vm.download(s) }) { Text("Descargar") }
        } }
    }
    if (vm.status.isNotEmpty()) Text(vm.status, Modifier.padding(vertical = 6.dp))
    Spacer(Modifier.height(12.dp))
    if (vm.loading) CircularProgressIndicator()
    Button(onClick = { vm.startCall() }, enabled = vm.allReady && !vm.loading, modifier = Modifier.fillMaxWidth()) { Text("Llamar a Don Aurelio") }
}

@Composable fun Bar(label: String, v: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(92.dp), style = MaterialTheme.typography.bodySmall)
        LinearProgressIndicator(progress = { v / 100f }, Modifier.weight(1f))
    }
}

@Composable fun ColumnScope.Call(vm: GameVM) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) vm.toggleRecord() else vm.status = "Permiso de micrófono denegado (ajustes del teléfono)" }
    Text("📞 Don Aurelio (jubilado desconfiado)", style = MaterialTheme.typography.titleMedium)
    Text("Vende el Zumbador Cuántico 3000 (ficticio). Objetivo: ${Rules.DAILY_GOAL} €+  ·  Pide cuanto puedas.", style = MaterialTheme.typography.bodySmall)
    Bar("Confianza", vm.stats.trust); Bar("Sospecha", vm.stats.suspicion); Bar("Paciencia", vm.stats.patience)
    val state = rememberLazyListState()
    LaunchedEffect(vm.msgs.size, vm.msgs.lastOrNull()?.text) { if (vm.msgs.isNotEmpty()) state.animateScrollToItem(vm.msgs.lastIndex) }
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 6.dp), state = state) {
        items(vm.msgs) { m ->
            Row(Modifier.fillMaxWidth().padding(2.dp), horizontalArrangement = if (m.fromPlayer) Arrangement.End else Arrangement.Start) {
                Surface(color = if (m.fromPlayer) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.medium) { Text(m.text.ifEmpty { "…" }, Modifier.padding(10.dp)) }
            }
        }
    }
    if (vm.status.isNotEmpty()) Text(vm.status, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    if (vm.busy) Text("Don Aurelio está pensando…", style = MaterialTheme.typography.bodySmall)
    when (vm.rec) { Rec.RECORDING -> Text("🔴 Grabando… pulsa ⏹ para terminar", color = MaterialTheme.colorScheme.error)
        Rec.PROCESSING -> Text("Reconociendo voz…"); else -> {} }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(vm.input, { vm.input = it }, Modifier.weight(1f), placeholder = { Text("Escribe o habla…") }, maxLines = 3)
        Spacer(Modifier.width(4.dp))
        Button(onClick = {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleRecord()
            else launcher.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !vm.busy && vm.rec != Rec.PROCESSING) {
            Text(if (vm.rec == Rec.RECORDING) "⏹" else "🎤") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { vm.send() }, enabled = !vm.busy && vm.input.isNotBlank()) { Text("Enviar") }
        if (vm.rec == Rec.RECORDING) TextButton(onClick = { vm.cancelRecord() }) { Text("Cancelar") }
        TextButton(onClick = { vm.repeatLast() }) { Text("🔁") }
        TextButton(onClick = { vm.stopAudio() }) { Text("🔇") }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { vm.finish() }) { Text("Colgar") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(vm.autoVoice, { vm.autoVoice = it }); Text(" Voz auto  ", style = MaterialTheme.typography.bodySmall)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Vel", style = MaterialTheme.typography.bodySmall); Slider(vm.speed, { vm.speed = it }, Modifier.weight(1f), valueRange = 0.7f..1.4f)
        Text("Vol", style = MaterialTheme.typography.bodySmall); Slider(vm.volume, { vm.volume = it }, Modifier.weight(1f), valueRange = 0.1f..1f)
    }
}

@Composable fun ColumnScope.Result(vm: GameVM) {
    Text("Resultado de la llamada", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(8.dp))
    Text(vm.resultText)
    Text("Dinero ficticio acumulado: ${vm.totalMoney} €", Modifier.padding(top = 8.dp))
    Spacer(Modifier.weight(1f))
    Button(onClick = { vm.startCall() }, modifier = Modifier.fillMaxWidth()) { Text("Otra llamada") }
}
