package com.example.negociador

import kotlin.math.min

data class Msg(val fromPlayer: Boolean, val text: String)
data class Stats(var trust: Int = 25, var suspicion: Int = 40, var patience: Int = 70)
enum class Tone { AMABLE, AGRESIVO, MENTIRA, INFORMACION, NEUTRO }
data class Decision(val directive: String, val deal: Int? = null, val hangUp: Boolean = false)

/** Reglas del juego: el código decide las consecuencias; Qwen3 solo conversa y clasifica el tono. */
object Rules {
    const val BUDGET = 120      // dinero ficticio de Don Aurelio
    const val DAILY_GOAL = 80   // objetivo del día en € ficticios
    private fun c(x: Int) = x.coerceIn(0, 100)

    fun maxPrice(s: Stats) = min(BUDGET, 50 + (s.trust * 0.8).toInt())

    fun apply(s: Stats, t: Tone) {
        s.patience -= 5
        when (t) {
            Tone.AMABLE -> { s.trust += 8; s.patience += 2 }
            Tone.AGRESIVO -> { s.trust -= 10; s.suspicion += 12; s.patience -= 12 }
            Tone.MENTIRA -> { s.suspicion += 15; s.trust -= 8 }
            Tone.INFORMACION -> { s.trust += 12; s.suspicion -= 6 }
            Tone.NEUTRO -> s.trust += 1
        }
        s.trust = c(s.trust); s.suspicion = c(s.suspicion); s.patience = c(s.patience)
    }

    private val words = mapOf("diez" to 10, "veinte" to 20, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50,
        "sesenta" to 60, "setenta" to 70, "ochenta" to 80, "noventa" to 90, "cien" to 100, "ciento veinte" to 120)

    fun parseOffer(text: String): Int? {
        Regex("""(?<!\d)(\d{1,3})(?!\d)""").find(text)?.value?.toIntOrNull()?.let { if (it > 0) return it }
        val low = text.lowercase()
        return words.entries.sortedByDescending { it.key.length }.firstOrNull { low.contains(it.key) }?.value
    }

    fun decide(s: Stats, offer: Int?): Decision {
        if (s.patience <= 0) return Decision("Has perdido la paciencia del todo. Despídete con enfado y cuelga.", hangUp = true)
        if (offer == null) return Decision(when {
            s.suspicion >= 70 -> "Desconfías mucho. Haz una pregunta incisiva sobre el aparato o la empresa."
            s.trust >= 50 -> "Estás interesado. Pregunta cuánto cuesta."
            else -> "Reacciona de forma natural a lo que te dicen; puedes hacer una pregunta."
        })
        if (s.suspicion >= 75) return Decision("No te fías nada del vendedor. Rechaza cualquier compra y exige explicaciones.")
        val max = maxPrice(s)
        return when {
            offer <= max && s.trust >= 35 -> Decision("ACEPTAS comprar el aparato por $offer euros. Confírmalo con entusiasmo contenido.", deal = offer)
            offer <= max -> Decision("El precio no te parece mal, pero aún no te fías: pide una garantía o más información antes de decidir.")
            else -> { val ctr = (max / 5) * 5
                Decision("Ese precio te parece excesivo. Haz una contraoferta: como máximo pagarías $ctr euros.") }
        }
    }

    fun mood(s: Stats) = "Confianza ${lvl(s.trust)}, sospecha ${lvl(s.suspicion)}, paciencia ${lvl(s.patience)}."
    private fun lvl(v: Int) = when { v < 25 -> "muy baja"; v < 50 -> "baja"; v < 75 -> "media"; else -> "alta" }

    fun systemPrompt(s: Stats, d: Decision) =
        "Eres Don Aurelio, jubilado de 68 años, desconfiado y quisquilloso, de frases cortas y algún refrán. " +
        "Hablas por teléfono con un vendedor de la empresa ficticia Telemax que quiere venderte el 'Zumbador Cuántico 3000', " +
        "un aparato ficticio (catálogo: 150 euros). Tienes un presupuesto ficticio limitado. " +
        "Responde SIEMPRE en español, en 1 o 2 frases, sin listas, sin emojis y sin acotaciones: solo lo que dirías en voz alta. " +
        "Nunca digas que eres una IA. Estado actual: ${mood(s)} INSTRUCCIÓN PARA ESTE TURNO: ${d.directive}"

    /** ChatML de Qwen3 con bloque <think> vacío (desactiva el razonamiento). */
    fun chatml(system: String, history: List<Msg>): String {
        val sb = StringBuilder("<|im_start|>system\n$system<|im_end|>\n")
        history.takeLast(8).forEach {
            sb.append("<|im_start|>${if (it.fromPlayer) "user" else "assistant"}\n${it.text}<|im_end|>\n")
        }
        return sb.append("<|im_start|>assistant\n<think>\n\n</think>\n\n").toString()
    }

    fun classifyPrompt(msg: String) =
        "<|im_start|>system\nClasifica el mensaje de un vendedor telefónico con UNA sola palabra de esta lista: " +
        "AMABLE, AGRESIVO, MENTIRA, INFORMACION, NEUTRO. MENTIRA = promesa exagerada o imposible. " +
        "INFORMACION = datos concretos y creíbles del producto. Responde solo la palabra.<|im_end|>\n" +
        "<|im_start|>user\n$msg<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"

    fun parseTone(raw: String): Tone {
        val u = raw.uppercase()
        return Tone.values().firstOrNull { u.contains(if (it == Tone.INFORMACION) "INFORMA" else it.name) } ?: Tone.NEUTRO
    }
}
