package com.example.negociador

import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

object Downloader {
    fun size(url: String): Long = try {
        (URL(url).openConnection() as HttpURLConnection).run {
            requestMethod = "HEAD"; connectTimeout = 15000; readTimeout = 15000
            val l = contentLengthLong; disconnect(); l
        }
    } catch (e: Exception) { -1 }

    fun fetch(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        val total = c.contentLengthLong
        c.inputStream.use { inp -> part.outputStream().use { out ->
            val buf = ByteArray(64 * 1024); var done = 0L
            while (true) {
                if (Thread.currentThread().isInterrupted) throw InterruptedIOException("cancelado")
                val n = inp.read(buf); if (n < 0) break
                out.write(buf, 0, n); done += n; onProgress(done, total)
            }
        } }
        part.renameTo(dest)
    }

    fun untarBz2(archive: File, target: File) {
        target.mkdirs()
        TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(archive.inputStream()))).use { tar ->
            while (true) {
                val e = tar.nextTarEntry ?: break
                val f = File(target, e.name)
                if (!f.canonicalPath.startsWith(target.canonicalPath)) continue // evita path traversal
                if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { tar.copyTo(it) } }
            }
        }
    }
}
