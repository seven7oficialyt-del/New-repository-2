package com.example.negociador

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Cliente mínimo de OpenRouter (API compatible con OpenAI). Opcional: requiere internet y clave. */
object Cloud {
    fun chat(key: String, model: String, messages: List<Pair<String, String>>, maxTokens: Int): String {
        if (key.isBlank()) throw IllegalStateException("falta la clave de OpenRouter")
        val arr = JSONArray()
        messages.forEach { (r, c) -> arr.put(JSONObject().put("role", r).put("content", c)) }
        val body = JSONObject().put("model", model.ifBlank { "openrouter/free" })
            .put("max_tokens", maxTokens).put("temperature", 0.8).put("messages", arr)
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) {
            val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(150) }
            throw IllegalStateException("HTTP $code: $msg")
        }
        val m = JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val content = if (m.isNull("content")) "" else m.getString("content")
        if (content.isBlank()) throw IllegalStateException("el modelo devolvió una respuesta vacía; reintenta")
        return content.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }
}
