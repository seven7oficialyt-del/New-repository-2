package com.example.negociador

import android.app.Application
import android.media.*
import android.os.StatFs
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.File

data class ModelSpec(val id: String, val label: String, val url: String, val check: String, val archive: Boolean, val extractTo: String = "")
enum class Screen { SETUP, CALL, RESULT }
enum class Rec { IDLE, RECORDING, PROCESSING }

class GameVM(private val app: Application) : AndroidViewModel(app) {
    private val root = File(app.filesDir, "models")
    val specs = listOf(
        ModelSpec("llm", "Qwen3-0.6B Q8_0 (conversación)",
            "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q8_0.gguf", "qwen3/Qwen3-0.6B-Q8_0.gguf", false),
        ModelSpec("asr", "Whisper base int8 (reconocer voz, es)",
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.tar.bz2",
            "asr/sherpa-onnx-whisper-base/base-encoder.int8.onnx", true, "asr"),
        ModelSpec("tts", "Piper es_ES davefx (voz del personaje)",
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-es_ES-davefx-medium.tar.bz2",
            "tts/vits-piper-es_ES-davefx-medium/es_ES-davefx-medium.onnx", true, "tts"))

    var screen by mutableStateOf(Screen.SETUP)
    val sizes = mutableStateMapOf<String, Long>()
    val progress = mutableStateMapOf<String, Float>()
    val ready = mutableStateMapOf<String, Boolean>()
    var status by mutableStateOf("")
    var loading by mutableStateOf(false)

    val msgs = mutableStateListOf<Msg>()
    var stats by mutableStateOf(Stats())
    var input by mutableStateOf("")
    var busy by mutableStateOf(false)
    var rec by mutableStateOf(Rec.IDLE)
    var autoVoice by mutableStateOf(true)
    var directSend by mutableStateOf(false)
    var speed by mutableStateOf(1.0f)
    var volume by mutableStateOf(1.0f)
    private val maxTokens = 300 // tope de seguridad interno, no ajustable
    var resultText by mutableStateOf("")
    var totalMoney by mutableStateOf(0)

    private var llm: Llm? = null; private var asr: Asr? = null; private var tts: Tts? = null
    private val dl = mutableMapOf<String, Job>()
    private var speakJob: Job? = null
    private var recJob: Job? = null
    @Volatile private var recording = false
    private var turns = 0
    private var dealPrice: Int? = null
    private var ended = false

    init { refresh() }

    private fun file(s: ModelSpec) = File(root, s.check)
    fun refresh() {
        specs.forEach { s -> ready[s.id] = file(s).exists()
            if (sizes[s.id] == null) viewModelScope.launch(Dispatchers.IO) { sizes[s.id] = Downloader.size(s.url) } }
    }
    val allReady get() = specs.all { ready[it.id] == true }
    fun sizeText(id: String) = sizes[id]?.let { if (it > 0) "%.0f MB".format(it / 1048576.0) else "tamaño desconocido" } ?: "consultando…"

    fun download(s: ModelSpec) {
        val need = ((sizes[s.id] ?: 0L).coerceAtLeast(0L) * (if (s.archive) 2.5 else 1.1)).toLong()
        if (StatFs(app.filesDir.path).availableBytes < need) { status = "Espacio insuficiente para ${s.label}"; return }
        dl[s.id] = viewModelScope.launch(Dispatchers.IO) {
            try {
                status = "Descargando ${s.label}…"
                val tmp = File(root, "${s.id}.download")
                Downloader.fetch(s.url, tmp) { d, t -> progress[s.id] = if (t > 0) d.toFloat() / t else 0f }
                if (s.archive) { status = "Descomprimiendo…"; Downloader.untarBz2(tmp, File(root, s.extractTo)); tmp.delete() }
                else { file(s).parentFile?.mkdirs(); tmp.renameTo(file(s)) }
                ready[s.id] = file(s).exists(); status = if (ready[s.id] == true) "Listo: ${s.label}" else "Descarga incompleta"
            } catch (e: Exception) { status = "Error de descarga: ${e.message}" }
            progress.remove(s.id)
        }
    }
    fun cancelDownload(id: String) { dl[id]?.cancel(); progress.remove(id); status = "Descarga cancelada" }

    // ---------- Llamada ----------
    fun startCall() {
        loading = true; status = "Cargando modelos en memoria…"
        viewModelScope.launch(Dispatchers.Default) {
            try {
                if (llm == null) llm = Llm(file(specs[0]).path).also { if (!it.ok) { llm = null; throw IllegalStateException("Qwen3 no se pudo cargar (¿poca RAM?)") } }
                if (asr == null) asr = Asr(file(specs[1]).parentFile!!)
                if (tts == null) tts = Tts(file(specs[2]).parentFile!!)
            } catch (t: Throwable) { status = "Error de carga: ${t.message}"; loading = false; return@launch }
            msgs.clear(); stats = Stats(); turns = 0; dealPrice = null; ended = false; input = ""
            screen = Screen.CALL; loading = false; status = ""
            reply(Rules.decide(stats, null).copy(directive = "Acabas de coger el teléfono; saluda con desconfianza."), hidden = true)
        }
    }

    fun send(text: String = input) {
        val t = text.trim()
        if (t.isEmpty() || busy || ended) return
        input = ""; msgs.add(Msg(true, t)); busy = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val l = llm ?: return@launch
                val sb = StringBuilder()
                l.gen(Rules.classifyPrompt(t), 5, 0f) { sb.append(it); true }
                val tone = Rules.parseTone(sb.toString())
                Rules.apply(stats, tone); stats = stats.copy()
                turns++
                val d = Rules.decide(stats, Rules.parseOffer(t))
                reply(d)
            } catch (e: Throwable) { status = "Error de IA: ${e.message}" }
            finally { busy = false }
        }
    }

    private suspend fun reply(d: Decision, hidden: Boolean = false) {
        val l = llm ?: return
        busy = true
        val hist = if (hidden) listOf(Msg(true, "(suena el teléfono y descuelgas)")) else msgs.toList()
        msgs.add(Msg(false, "")); val idx = msgs.lastIndex
        val sb = StringBuilder()
        val ok = l.gen(Rules.chatml(Rules.systemPrompt(stats, d), hist), maxTokens, 0.8f) { p ->
            sb.append(p); msgs[idx] = Msg(false, sb.toString()); true }
        val clean = sb.toString().replace(Regex("(?s)<think>.*?</think>"), "").trim()
        if (!ok || clean.isEmpty()) { msgs.removeAt(idx); status = "La IA no generó respuesta (reintenta)"; busy = false; return }
        msgs[idx] = Msg(false, clean)
        if (autoVoice) speak(clean)
        if (d.deal != null) { dealPrice = d.deal; finish() } else if (d.hangUp) finish()
        busy = false
    }

    fun speak(text: String) {
        speakJob?.cancel()
        val t = tts ?: return
        speakJob = viewModelScope.launch(Dispatchers.Default) {
            try { t.speak(text, speed, volume) } catch (e: CancellationException) { throw e } catch (e: Throwable) { status = "Error de voz: ${e.message}" }
        }
    }
    fun repeatLast() { msgs.lastOrNull { !it.fromPlayer }?.let { speak(it.text) } }
    fun stopAudio() { speakJob?.cancel() }

    // ---------- Micrófono ----------
    fun toggleRecord() {
        if (busy || ended) return
        if (rec == Rec.RECORDING) { recording = false; return }
        if (rec != Rec.IDLE) return
        stopAudio(); rec = Rec.RECORDING; recording = true
        recJob = viewModelScope.launch(Dispatchers.IO) {
            val sr = 16000
            val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = try { AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2) }
                     catch (e: SecurityException) { status = "Sin permiso de micrófono"; rec = Rec.IDLE; return@launch }
            val chunks = ArrayList<ShortArray>(); var total = 0
            val buf = ShortArray(sr / 5)
            try {
                ar.startRecording()
                while (recording && total < sr * 30) {
                    val n = ar.read(buf, 0, buf.size); if (n > 0) { chunks.add(buf.copyOf(n)); total += n }
                }
            } finally { ar.stop(); ar.release() }
            if (!recording && rec == Rec.IDLE) return@launch   // cancelado
            recording = false; rec = Rec.PROCESSING
            if (total < sr / 3) { status = "Audio demasiado corto"; rec = Rec.IDLE; return@launch }
            val f = FloatArray(total); var o = 0
            chunks.forEach { c -> for (v in c) f[o++] = v / 32768f }
            val text = try { asr?.transcribe(f).orEmpty() } catch (e: Throwable) { status = "Error de reconocimiento: ${e.message}"; "" }
            rec = Rec.IDLE
            if (text.isBlank()) { status = "No te he entendido, prueba otra vez"; return@launch }
            if (directSend) send(text) else input = text   // el jugador puede corregir antes de enviar
        }
    }
    fun cancelRecord() { if (rec == Rec.RECORDING) { rec = Rec.IDLE; recording = false } }

    // ---------- Resultado ----------
    fun finish() {
        if (ended) return
        ended = true; stopAudio()
        val p = dealPrice
        if (p != null) {
            totalMoney += p
            resultText = "¡Trato cerrado por $p € ficticios en $turns turnos!\n" +
                if (p >= Rules.DAILY_GOAL) "Objetivo del día (${Rules.DAILY_GOAL} €) CUMPLIDO." else "No llegas al objetivo del día (${Rules.DAILY_GOAL} €)."
        } else resultText = "Sin venta tras $turns turnos. Confianza ${stats.trust}, sospecha ${stats.suspicion}, paciencia ${stats.patience}."
        screen = Screen.RESULT
    }

    override fun onCleared() { llm?.close(); asr?.close(); tts?.close() }
}
