# Negociador — prototipo (Android, Kotlin + Compose)

Una llamada: tú vendes el "Zumbador Cuántico 3000" (ficticio) a Don Aurelio.
Hablas o escribes → Whisper (ASR) → Qwen3-0.6B (llama.cpp) → Piper (TTS). Todo local.

## ESTADO REAL
Escrito pero NO compilado ni probado (el entorno donde se generó no tiene Android SDK/NDK ni red).
Esperan errores de compilación menores, sobre todo en el JNI de llama.cpp y en nombres del API de sherpa-onnx.

## Pasos para compilarlo (Android Studio, NDK + CMake 3.22 instalados)
1. llama.cpp:  git clone https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
   (si falla un nombre de función en llama_jni.cpp, tu versión es distinta: ajusta ahí)
2. sherpa-onnx — del release Android (sherpa-onnx-v1.x.x-android.tar.bz2):
   - copia jniLibs/arm64-v8a/*.so  → app/src/main/jniLibs/arm64-v8a/
   - copia los .kt de https://github.com/k2-fsa/sherpa-onnx/tree/master/sherpa-onnx/kotlin-api
     → app/src/main/java/com/k2fsa/sherpa/onnx/   (OfflineRecognizer, OfflineTts, FeatureConfig, etc.)
3. Abre la carpeta en Android Studio, sincroniza y ejecuta en un móvil arm64 (no emulador x86).
4. En la app: descarga los 3 modelos (~640 MB + ~150 MB + ~60-80 MB; la app muestra el tamaño real) y llama.

## Qué incluye
- Descarga con progreso, cancelar, tamaño previo y comprobación de espacio.
- Conversación libre por texto o voz; voz → texto editable (o envío directo).
- Qwen3 genera cada respuesta en streaming; otra llamada corta a Qwen3 clasifica el tono del jugador.
- Reglas en código: confianza/sospecha/paciencia, precio máximo, trato, objetivo diario de 80 €.
- TTS con repetir/parar, volumen, velocidad, voz automática.
- Errores de carga/RAM/IA mostrados sin cerrar la app.

## Qué NO incluye aún (a propósito, para probar si es divertido)
Memoria persistente y resúmenes (solo últimos 8 mensajes), guardado, oficina, varios personajes,
voces distintas, mejoras, estadísticas, cola de audio (solo se reproduce la última respuesta).
